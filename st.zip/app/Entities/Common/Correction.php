<?php

namespace App\Entities\Common;

use App\Entities\Model;

class Correction extends Model
{
    protected $guarded = ['id'];
}
